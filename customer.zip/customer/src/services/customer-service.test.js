// which service it is
describe("CustomerService", () => {
  // Which function
  describe("SignIn", () => {
    // Which Scenario we are testing
    test("validate user inputs", () => {});

    test("Validate response", async () => {});
  });
});
